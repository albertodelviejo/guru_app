class UserBloc {

  //Business Logic Components

  //Use case 1 : Login in the app from form


}
